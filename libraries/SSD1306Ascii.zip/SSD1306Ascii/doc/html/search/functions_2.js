var searchData=
[
  ['displayheight_0',['displayHeight',['../class_s_s_d1306_ascii.html#ad6c0f15653c2d8270ffffbd8d74ebe12',1,'SSD1306Ascii']]],
  ['displayremap_1',['displayRemap',['../class_s_s_d1306_ascii.html#ab05fbcc3a2f70c35d93b1aa0fdf61f4d',1,'SSD1306Ascii']]],
  ['displayrows_2',['displayRows',['../class_s_s_d1306_ascii.html#ad949fa2fa919f5fa4975f40b4c91f18d',1,'SSD1306Ascii']]],
  ['displaywidth_3',['displayWidth',['../class_s_s_d1306_ascii.html#af36e4034fe1c8c90204bd8a14309619f',1,'SSD1306Ascii']]]
];
